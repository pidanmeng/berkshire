---
batchId: 20260815-batch-003-approved
parentBatch: 20260815-batch-003
status: verified
approved_at: 2026-08-15
origin: process-improvement
---

# 优化批次：财务排雷数据闭环 + 估值类型路由消费（2026-08-15-batch-003-approved）

## 批次来源

部分批准子批次（父批次 `20260815-batch-003` 用户勾选 3 项；宏观层未勾选转 rejected）：

| 候选 | 问题码 | 严重度 | 目标文件 |
|---|---|---|---|
| 排雷数据生产端补齐（evaluate 输出利息覆盖/应收增速/货币资金占比） | `eval-missing-trap-inputs` | high | `.trae/scripts/evaluation/evaluate.ts` |
| 精读模板补原文提取字段（现金收入比/存货增速/短债占比/商誉） | `missing-mine-field-extraction` | high | `.trae/agents/document-reader.md` |
| info-hunter 消费 `--type` 企业类型路由 | `eval-type-param-usage-missing` | high | `.trae/agents/info-hunter.md` |

## 逐文件修改清单

| 文件 | 变更类型 | 变更内容 |
|---|---|---|
| `.trae/scripts/evaluation/evaluate.ts` | 修改 | 新增「排雷数据生产端输出」章节：利息覆盖倍数（OCF÷利息支出）、应收增速（多期应收对比）、货币资金/总资产占比；格式与 quality-screen report 模式正则兼容；缺项显式输出 N/A |
| `.trae/scripts/evaluation/__tests__/evaluate.test.ts` | 修改（测试） | 新增 2 用例：三项指标正确性 + 数据缺失 N/A 不崩溃 |
| `.trae/agents/document-reader.md` | 修改 | 精读目标 3「财务状况」新增「原文排雷字段」小节（现金收入比/存货增速/短债占比/商誉净额，要求原文提取、注明出处、缺项显式 N/A 禁止臆造）；输出结构新增 4.4 节；质量标准新增检查项 |
| `.trae/agents/info-hunter.md` | 修改 | evaluate.ts 调用强制传 `--type`（金融/周期/资源/控股集团/一般工商），给出判定依据与示例；采集顺序步骤 3 与质量标准同步补充 |

## 兼容性

- evaluate.ts 为**新增输出**，不改变既有章节结构与输出字段；未传 `--type` 行为不变。
- document-reader 为**新增精读要求**，不与既有 7 大目标冲突。
- info-hunter 为**用法补充**，`--type` 已是 evaluate 既有参数，仅提示词消费。

## 依赖顺序

1. `evaluate.ts` 三项指标输出（无依赖，先行）。
2. `document-reader.md` 精读字段（独立）。
3. `info-hunter.md` `--type` 用法（独立）。
4. 测试文件随脚本同步更新。

## 强制验证（见 verification 文档）

- [x] 批次专项测试（evaluate 16 项，含新增 2 项，全部通过）
- [x] 全量 bun test（99 通过 / 1 既有环境性失败，与本批次无关）
- [x] bun build --no-bundle 语法检查（2 文件 exit 0）
- [x] 路径检查：实际改动 ⊆ 批准集合 + 测试资产，未触及未批准文件（AGENTS.md 未改）

## 回滚方案

- 基线快照：`06-Process-Improvement/baselines/2026-08-15-batch-003-approved/`（evaluate.ts / document-reader.md / info-hunter.md）。
- 回滚：覆盖还原基线 + 删除新增测试用例 + 回归验证。

## 排除项

- 宏观层（AGENTS.md，`macro-environment-scan-layer`）未获批准，不在本批次。
- observing 项（报告模板价值区间、50-item checklist 行为纪律、bubble 五问、机制阻断、能力圈三条件、批量摄取、allowedPaths 测试资产）不纳入。
