---
batchId: 20260815-batch-003
status: rejected
decision: partial
origin: process-improvement
---

# 优化批次：财务排雷数据闭环 + 宏观层 + 估值类型路由消费（2026-08-15-batch-003）

> 用户选择**部分批准**：3 项批准（已转 `20260815-batch-003-approved` 子批次并验证），宏观层（AGENTS.md）未勾选转 `rejected`。

## 批次来源

backlog 中当前 4 个 `candidate` 汇总（去重后按 严重度→置信度→指纹 排序），来自三个任务：

| 候选 | 问题码 | 严重度 | 证据 | 目标文件 |
|---|---|---|---|---|
| 排雷数据生产端补齐（evaluate 输出利息覆盖/应收增速/货币资金占比） | `eval-missing-trap-inputs` | high | A（hithink 字段已核实可算）+ D | `.trae/scripts/evaluation/evaluate.ts` |
| 精读模板补原文提取字段（现金收入比/存货增速/短债占比/商誉） | `missing-mine-field-extraction` | high | A（hithink 无字段，仅原文可得）+ D | `.trae/agents/document-reader.md` |
| 宏观环境扫描层（Phase 0.5，约束型非择时） | `macro-environment-scan-layer` | high | A（99-宏观/ 空目录已核实）+ D | `AGENTS.md` |
| info-hunter 消费 `--type` 企业类型路由 | `eval-type-param-usage-missing` | high | A（evaluate 已支持 --type，提示词未消费）+ D | `.trae/agents/info-hunter.md` |

## 逐文件修改清单

| 文件 | 变更类型 | 变更内容 |
|---|---|---|
| `.trae/scripts/evaluation/evaluate.ts` | 修改 | 在盈利质量信号/估值章节补输出：利息覆盖倍数（OCF÷利息支出）、应收增速（多期应收对比）、货币资金/总资产占比，供 quality-screen report 模式消费 |
| `.trae/scripts/evaluation/__tests__/evaluate.test.ts` | 修改（测试） | 新增用例：三项指标输出正确性与口径（利息覆盖分母用利息支出、应收同比、货币资金占比） |
| `.trae/agents/document-reader.md` | 修改 | 精读目标（财务状况章节）要求从财报原文提取并记录：现金收入比/存货增速/短债占比/商誉净额，写入 deep-read 输出；缺项显式标注 |
| `AGENTS.md` | 修改 | 新增 Phase 0.5 宏观环境扫描（约束型非择时）：库存周期定位 + 利率/信用环境；填充 `Research/10-Knowledge/99-宏观/`；明确"只做排除与约束，不做择时" |
| `.trae/agents/info-hunter.md` | 修改 | 强制操作补 `--type` 用法，要求评估时按行业属性指定企业类型（周期/金融等），并给类型判定提示 |
| `Research/00-Workspace/06-Process-Improvement/` | 新增 | 批次文档、baselines/、verification 文档 |

> 治理说明：候选 targetPath 自动生成 allowedPaths（4 个正式资产）。测试文件属于对应脚本组成部分随批次修改；本批次涉及 Agent/AGENTS.md 等正式资产，需用户批准后实施。

## 兼容性

- evaluate.ts 为**新增输出**，不改变既有章节结构，旧输出字段不变。
- document-reader 为**新增精读要求**，不与既有 7 大目标冲突。
- AGENTS.md 新增 Phase 0.5 为**增量环节**，置于 Phase 1 之前，不改变既有六阶段顺序。
- info-hunter 为**用法补充**，`--type` 已是 evaluate 既有参数，仅提示词消费。

## 依赖顺序

1. `evaluate.ts` 输出三项排雷指标（无依赖，先行）。
2. `document-reader.md` 精读字段（依赖 evaluate 补齐后 quality-screen 可判，独立）。
3. `info-hunter.md` `--type` 用法（依赖已应用批次的能力，独立）。
4. `AGENTS.md` 宏观层（独立）。
5. 各测试文件随脚本同步更新。

## 强制验证

- [ ] 批次专项测试（evaluate 新增用例 + 既有全量）
- [ ] 全量 `bun test`
- [ ] `bun build --no-bundle` 语法检查 / `bunx tsc --noEmit`
- [ ] 路径检查：实际 diff 文件集合 ⊆ 批准集合

## 回滚方案

- 基线快照：`06-Process-Improvement/baselines/2026-08-15-batch-003/` 下保存各文件修改前副本。
- 回滚：覆盖还原 + 删除新增测试用例 + 回归验证。
- 任一强制验证失败 → 按回滚清单恢复，标记 `apply_failed`。

## 排除项

- observing 项（报告模板价值区间、50-item checklist 行为纪律、bubble 五问、机制阻断、能力圈三条件、批量摄取、allowedPaths 测试资产）不纳入。
- 已 rejected 的 `macro-layer-missing`（旧指纹）不重复纳入；本批次为重新入池的 `macro-environment-scan-layer`。
