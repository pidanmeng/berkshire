# 流程改进 Backlog

> 状态真源：improvement-backlog.json · 最后更新：2026-08-15T10:01:57.385Z

| 状态 | 严重度 | 问题描述 | 目标文件 | 任务数 | 问题码 |
|---|---|---|---|---:|---|
| 已拒绝 | 高 | 六阶段流程无宏观分析环节，99-宏观/ 目录仅有占位空目录，行业估值与利率/信用环境脱钩 | AGENTS.md | 1 | macro-layer-missing |
| 已验证 | 高 | 估值快照仅四个倍数(PE/PB/PS/PCF) + 机械情景 PE 外推，无企业类型路由/周期正常化/价值区间/安全边际… | .trae/scripts/evaluation/evaluate.ts | 1 | mechanical-pe-extrapolation |
| 已验证 | 高 | 8 项财务红牌缺资产质量与现金偿息维度：无现金收入比/利息覆盖/应收存货增速对比/债务期限结构/存贷双高/商誉/监管记录 | .trae/scripts/quality-gate/quality-screen.ts | 1 | missing-financial-trap-flags |
| 观察 | 中 | 报告估值章节以点值目标价(保守估值×0.8买入/乐观上沿卖出)为导向，缺价值区间与安全边际显式判断；跟踪指标无证伪映射 | Research/99-Templates/report-template.md | 1 | point-estimate-valuation-in-template |
| 观察 | 中 | 50-item checklist 缺心态/纪律类条目：止损侥幸心理、交易与配置分离声明、情绪决策分离 | .trae/skills/research-quality-gate/scripts/investment-checklist-auto.ts | 1 | behavioral-discipline-items-missing |
| 观察 | 中 | 精读 7 大目标以净利润层面为主，缺毛利层/营业利润层/净利润层三级同步性与三类现金流组合五态检查 | .trae/agents/document-reader.md | 1 | missing-profit-ladder-synchronization |
| 观察 | 中 | 反共识检验为开放式提问，无结构化清单；缺情绪逆向指标(主题被反复问起=情绪高位) | .trae/agents/cross-validator.md | 1 | bubble-question-checklist-missing |
| 观察 | 低 | 采集清单无'涨价传导链'机制阻断检查，题材/涨价逻辑缺反向验证 | .trae/agents/info-hunter.md | 1 | missing-mechanism-block-check |
| 观察 | 低 | 能力圈标注偏定性(能否一句话说清+预测10年)，无一致性判据 | Research/99-Templates/company-template.md | 1 | capability-circle-criteria-vague |
| 观察 | 低 | 摄取脚本仅支持单文件，批量摄取 48 个 PDF 需临时自写脚本(.trae/tmp/batch-extract-zhe… | .trae/scripts/file-ingestion/fetch-file.ts | 1 | no-batch-ingestion-mode |
| 已拒绝 | 高 | 六阶段流程无宏观分析环节，99-宏观/ 目录为空；宏观层在批次 20260815-batch-001 部分批准中被暂缓，… | AGENTS.md | 1 | macro-environment-scan-layer |
| 观察 | 低 | build-batch 生成的批次 allowedPaths 仅含候选 targetPath（脚本文件），未包含随脚本变… | .trae/skills/research-process-optimization/scripts/improvement-backlog.ts | 1 | batch-allowedpaths-missing-test-assets |
| 已验证 | 高 | evaluate.ts 未输出利息覆盖倍数/应收增速/货币资金占比等可算排雷指标，quality-screen 新增排雷… | .trae/scripts/evaluation/evaluate.ts | 1 | eval-missing-trap-inputs |
| 已验证 | 高 | 现金收入比/存货增速/短债占比/商誉四项排雷数据 hithink 接口无字段，只能从财报原文提取，但 document-… | .trae/agents/document-reader.md | 1 | missing-mine-field-extraction |
| 已验证 | 高 | evaluate.ts 已新增 --type 企业类型参数，但 info-hunter 调用示例仅含 --code/--… | .trae/agents/info-hunter.md | 1 | eval-type-param-usage-missing |
